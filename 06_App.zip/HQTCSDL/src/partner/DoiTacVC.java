/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package partner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
public class DoiTacVC extends javax.swing.JFrame {
    DefaultTableModel tblModel = new DefaultTableModel();

/**
 * Creates new form DoiTacVC
 */
public DoiTacVC() {
initComponents();
setLocationRelativeTo(null);
showDT();
}
 public void showDT() {
       try{
            Class.forName("oracle.jdbc.driver.OracleDriver");       
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "partner", "p1");
            System.out.println("Connected to the database");           
            Statement st = con.createStatement();
            String orc = "select * from YUN.DoiTacVC where ma_DT ='DT01'" ;
            ResultSet rs = st.executeQuery(orc);
            this.tblModel = (DefaultTableModel)tblDT.getModel(); 
            String column[] = {"Mã đối tác","Mã số thuế","Tên đối tác","Người đại diện","Số chi nhánh", "Thành phố", "Quận","Mã loại hàng","Địa chỉ kinh doanh", "Số điện thoại", "Email", "Số lượng đơn/ngày" };
            this.tblModel.setColumnIdentifiers(column);
            this.tblDT.setModel(tblModel);
            while(rs.next()){
                   Object[] row = new Object[12];
                   row[0] = rs.getString("ma_DT");
                   row[1] = rs.getString("ma_so_thue");
                   row[2] = rs.getString("ten_DT");
                   row[3] = rs.getString("nguoi_dai_dien");
                   row[4] = rs.getInt("so_chi_nhanh");
                   row[5] = rs.getString("thanh_pho");
                   row[6] = rs.getString("quan");
                   row[7] = rs.getString("ma_loai_hang_VC");
                   row[8] = rs.getString("dia_chi_kinh_doanh");
                   row[9] = rs.getInt("sdt_VC");
                   row[10] = rs.getString("email_VC");
                   row[11] = rs.getInt("sl_dh_moi_ngay");
                   this.tblModel.addRow(row);
                }                      
            }
       catch(Exception E){
            System.out.println("Connection failed");
            E.printStackTrace();
        }
}


@SuppressWarnings("unchecked")
// <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
private void initComponents() {

jLabel1 = new javax.swing.JLabel();
jScrollPane1 = new javax.swing.JScrollPane();
tblDT = new javax.swing.JTable();
jButton2 = new javax.swing.JButton();

setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
jLabel1.setText("Thông tin");

tblDT.setModel(new javax.swing.table.DefaultTableModel(
new Object [][] {

},
new String [] {
"Mã đối tác", "Mã số thuế", "Tên đối tác", "Người đại diện", "Số chi nhánh", "Thành phố", "Quận", "Mã loại hàng", "Địa chỉ kinh doanh", "Số điện thoại", "Email", "Số lượng đơn/ngày"
}
));
jScrollPane1.setViewportView(tblDT);
if (tblDT.getColumnModel().getColumnCount() > 0) {
tblDT.getColumnModel().getColumn(5).setMaxWidth(35);
tblDT.getColumnModel().getColumn(6).setMinWidth(10);
tblDT.getColumnModel().getColumn(6).setMaxWidth(10);
}

jButton2.setText("Quay lại");
jButton2.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
jButton2ActionPerformed(evt);
}
});

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addComponent(jScrollPane1)
.addContainerGap())
.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
.addGap(40, 40, 40)
.addComponent(jButton2)
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 614, Short.MAX_VALUE)
.addComponent(jLabel1)
.addGap(530, 530, 530))
);
layout.setVerticalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel1)
.addComponent(jButton2))
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
.addGap(60, 60, 60))
);

pack();
}// </editor-fold>//GEN-END:initComponents

private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
dispose();
Partner_Manage dhpage = new Partner_Manage();
dhpage.show();
}//GEN-LAST:event_jButton2ActionPerformed


public static void main(String args[]) {
/* Set the Nimbus look and feel */
//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
 */
try {
for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
if ("Nimbus".equals(info.getName())) {
javax.swing.UIManager.setLookAndFeel(info.getClassName());
break;
}
}
} catch (ClassNotFoundException ex) {
java.util.logging.Logger.getLogger(DoiTacVC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
java.util.logging.Logger.getLogger(DoiTacVC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
java.util.logging.Logger.getLogger(DoiTacVC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (javax.swing.UnsupportedLookAndFeelException ex) {
java.util.logging.Logger.getLogger(DoiTacVC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}
//</editor-fold>

/* Create and display the form */
java.awt.EventQueue.invokeLater(new Runnable() {
public void run() {
new DoiTacVC().setVisible(true);
}
});
}

// Variables declaration - do not modify//GEN-BEGIN:variables
private javax.swing.JButton jButton2;
private javax.swing.JLabel jLabel1;
private javax.swing.JScrollPane jScrollPane1;
private javax.swing.JTable tblDT;
// End of variables declaration//GEN-END:variables
}
