/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author PC
 */
public class ThongTin extends javax.swing.JFrame {

/**
 * Creates new form ThongTin
 */
public ThongTin() {
initComponents();
setLocationRelativeTo(null);

txt_MKH.setEditable(false);
txt_HT.setEditable(false);
txt_Email.setEditable(false);
     
try{      
   String query ="select dia_chi_KH from YUN.KhachHang where ma_KH='KH03'";
     Class.forName("oracle.jdbc.driver.OracleDriver");       
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "customer", "c1");
     //String orc ="update YUN.sanPham set ten_san_pham=?, ma_nha_cung_cap=?, ma_loai_hang=?, gia_nhap=?, gia_ban=? where ma_SP = ?";
      //con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // chỉnh giá sản phẩm cho Non-read
       Statement st = con.createStatement();
       ResultSet rs = st.executeQuery(query);

        if (rs.next())
{
     txt_DC.setText(rs.getString("dia_chi_KH"));
     //txt_DC.setText(rs.setText("dia_chi_KH"));
}
       else { txt_DC.setText("");}
   } catch(Exception e)
{
       JOptionPane.showMessageDialog(this,e.getMessage());
}
try{      
   String query ="select sdt_KH from YUN.KhachHang where ma_KH='KH03'";
     Class.forName("oracle.jdbc.driver.OracleDriver");       
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "customer", "c1");
     //String orc ="update YUN.sanPham set ten_san_pham=?, ma_nha_cung_cap=?, ma_loai_hang=?, gia_nhap=?, gia_ban=? where ma_SP = ?";
      //con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // chỉnh giá sản phẩm cho Non-read
       Statement st = con.createStatement();
       ResultSet rs = st.executeQuery(query);

        if (rs.next())
{
     txt_SDT.setText(rs.getString("sdt_KH"));
     //txt_DC.setText(rs.setText("dia_chi_KH"));
}
       else { txt_DC.setText("");}
   } catch(Exception e)
{
       JOptionPane.showMessageDialog(this,e.getMessage());
}
}

@SuppressWarnings("unchecked")
// <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
private void initComponents() {

jLabel1 = new javax.swing.JLabel();
jLabel2 = new javax.swing.JLabel();
jLabel3 = new javax.swing.JLabel();
jLabel4 = new javax.swing.JLabel();
jLabel5 = new javax.swing.JLabel();
jLabel6 = new javax.swing.JLabel();
txt_HT = new javax.swing.JTextField();
txt_DC = new javax.swing.JTextField();
txt_MKH = new javax.swing.JTextField();
txt_SDT = new javax.swing.JTextField();
txt_Email = new javax.swing.JTextField();
btn_Save = new javax.swing.JButton();
btn_GH = new javax.swing.JButton();
jButton1 = new javax.swing.JButton();

setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
jLabel1.setText("Thông tin cá nhân");

jLabel2.setText("Mã khách hàng");

jLabel3.setText("Họ tên");

jLabel4.setText("Địa chỉ khách hàng");

jLabel5.setText("Số điện thoại");

jLabel6.setText("Email");

txt_HT.setText("Trần Thị C");
txt_HT.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_HTActionPerformed(evt);
}
});

txt_DC.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_DCActionPerformed(evt);
}
});

txt_MKH.setText("KH03");
txt_MKH.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_MKHActionPerformed(evt);
}
});

txt_SDT.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_SDTActionPerformed(evt);
}
});

txt_Email.setText("ttc22d2@gmail.com");

btn_Save.setText("LƯU");
btn_Save.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_SaveActionPerformed(evt);
}
});

btn_GH.setText("Đơn hàng");
btn_GH.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_GHActionPerformed(evt);
}
});

jButton1.setText("Quay lại");
jButton1.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
jButton1ActionPerformed(evt);
}
});

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
.addGroup(layout.createSequentialGroup()
.addGap(53, 53, 53)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel2)
.addComponent(jLabel4)
.addComponent(jLabel6))
.addGap(62, 62, 62)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
.addGroup(layout.createSequentialGroup()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(txt_MKH, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(txt_DC, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(73, 73, 73)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel3)
.addComponent(jLabel5))
.addGap(30, 30, 30)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(txt_HT, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
.addGroup(layout.createSequentialGroup()
.addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
.addComponent(btn_Save)
.addGap(50, 50, 50))))
.addGroup(layout.createSequentialGroup()
.addGap(37, 37, 37)
.addComponent(jButton1)
.addGap(143, 143, 143)
.addComponent(jLabel1)
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
.addComponent(btn_GH)))
.addContainerGap(45, Short.MAX_VALUE))
);
layout.setVerticalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel1)
.addComponent(btn_GH)
.addComponent(jButton1))
.addGap(26, 26, 26)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel2)
.addComponent(txt_MKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jLabel3)
.addComponent(txt_HT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(54, 54, 54)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel4)
.addComponent(txt_DC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jLabel5)
.addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(49, 49, 49)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel6)
.addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(btn_Save))
.addContainerGap(25, Short.MAX_VALUE))
);

pack();
}// </editor-fold>//GEN-END:initComponents

private void txt_MKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_MKHActionPerformed
txt_MKH.setEditable(false);

}//GEN-LAST:event_txt_MKHActionPerformed

private void txt_HTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_HTActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_HTActionPerformed

private void txt_SDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_SDTActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_SDTActionPerformed

private void btn_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SaveActionPerformed

     
try{      
     String query ="Update YUN.KhachHang set dia_chi_KH=? , sdt_KH=? where  ma_KH='KH03'";
     Class.forName("oracle.jdbc.driver.OracleDriver");       
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "customer", "c1");
     //String orc ="update YUN.sanPham set ten_san_pham=?, ma_nha_cung_cap=?, ma_loai_hang=?, gia_nhap=?, gia_ban=? where ma_SP = ?";
      //con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // chỉnh giá sản phẩm cho Non-read
      PreparedStatement pst = con.prepareStatement(query);
      pst.setString(1, txt_DC.getText());
      pst.setString(2, txt_SDT.getText());

      pst.executeUpdate();
      JOptionPane.showMessageDialog(this,"Update Successfully");

   } catch(Exception e)
{
       JOptionPane.showMessageDialog(this,e.getMessage());
}



}//GEN-LAST:event_btn_SaveActionPerformed

private void txt_DCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DCActionPerformed
     
}//GEN-LAST:event_txt_DCActionPerformed

private void btn_GHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_GHActionPerformed
        dispose();
        FRDonHang hpage = new FRDonHang();
        hpage.show();


}//GEN-LAST:event_btn_GHActionPerformed

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        Customer_Manage managepage = new Customer_Manage();
        managepage.show();// TODO add your handling code here:
}//GEN-LAST:event_jButton1ActionPerformed

/**
 * @param args the command line arguments
 */
public static void main(String args[]) {
/* Set the Nimbus look and feel */
//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
 */
try {
for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
if ("Nimbus".equals(info.getName())) {
javax.swing.UIManager.setLookAndFeel(info.getClassName());
break;
}
}
} catch (ClassNotFoundException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (javax.swing.UnsupportedLookAndFeelException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}
//</editor-fold>

/* Create and display the form */
java.awt.EventQueue.invokeLater(new Runnable() {
public void run() {
new ThongTin().setVisible(true);
}
});
}

// Variables declaration - do not modify//GEN-BEGIN:variables
private javax.swing.JButton btn_GH;
private javax.swing.JButton btn_Save;
private javax.swing.JButton jButton1;
private javax.swing.JLabel jLabel1;
private javax.swing.JLabel jLabel2;
private javax.swing.JLabel jLabel3;
private javax.swing.JLabel jLabel4;
private javax.swing.JLabel jLabel5;
private javax.swing.JLabel jLabel6;
private javax.swing.JTextField txt_DC;
private javax.swing.JTextField txt_Email;
private javax.swing.JTextField txt_HT;
private javax.swing.JTextField txt_MKH;
private javax.swing.JTextField txt_SDT;
// End of variables declaration//GEN-END:variables
}
