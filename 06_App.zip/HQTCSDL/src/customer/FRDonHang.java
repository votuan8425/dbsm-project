/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PC
 */
public class FRDonHang extends javax.swing.JFrame {
    DefaultTableModel tblModel = new DefaultTableModel();

/**
 * Creates new form JRDonHang
 */
public FRDonHang() {
initComponents();
        ngclList();
        setLocationRelativeTo(null);
    }
    public void ngclList() {
       try{
            Class.forName("oracle.jdbc.driver.OracleDriver");       
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "customer", "c1");
            System.out.println("Connected to the database");           
            Statement st = con.createStatement();
            String orc = "select * from YUN.DonHang where ma_KH='KH03'" ;
            ResultSet rs = st.executeQuery(orc);
            this.tblModel = (DefaultTableModel)tblDH.getModel(); 
            String column[] = {"Mã đơn hàng","Mã khách hàng","Mã nhân viên","Mã khuyến mãi","Mã sản phẩm", "Số lượng"};
            this.tblModel.setColumnIdentifiers(column);
            this.tblDH.setModel(tblModel);
            while(rs.next()){
                   Object[] row = new Object[6];
                   row[0] = rs.getString("ma_DH");
                   row[1] = rs.getString("ma_KH");
                   row[2] = rs.getString("ma_NV");
                   row[3] = rs.getString("ma_KM");
                   row[4] = rs.getString("ma_SP");
                   row[5] = rs.getInt("so_luong");

                   this.tblModel.addRow(row);
                }                      
            }
       catch(Exception E){
            System.out.println("Connection failed");
            E.printStackTrace();
        }
}
@SuppressWarnings("unchecked")
// <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
private void initComponents() {

jLabel1 = new javax.swing.JLabel();
jScrollPane1 = new javax.swing.JScrollPane();
tblDH = new javax.swing.JTable();
btn_BUY = new javax.swing.JButton();
btn_rf = new javax.swing.JButton();
txtBill = new javax.swing.JTextField();
jLabel2 = new javax.swing.JLabel();
jButton1 = new javax.swing.JButton();

setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
jLabel1.setText("Đơn Hàng");

tblDH.setModel(new javax.swing.table.DefaultTableModel(
new Object [][] {

},
new String [] {
"Mã đơn hàng", "Mã khách hàng", "Mã nhân viên", "Mã khuyến mãi", "Mã sản phẩm", "Số lượng"
}
));
jScrollPane1.setViewportView(tblDH);

btn_BUY.setText("Xem danh sách sản phẩm");
btn_BUY.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_BUYActionPerformed(evt);
}
});

btn_rf.setText("Cập nhật");
btn_rf.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_rfActionPerformed(evt);
}
});

jLabel2.setText("Số tiền bạn cần phải trả");

jButton1.setText("Quay lại");
jButton1.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
jButton1ActionPerformed(evt);
}
});

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGap(77, 77, 77)
.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
.addGap(18, 18, 18)
.addComponent(btn_BUY))
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addComponent(jButton1)
.addGap(281, 281, 281)
.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGroup(layout.createSequentialGroup()
.addGap(130, 130, 130)
.addComponent(jLabel2)
.addGap(68, 68, 68)
.addComponent(txtBill, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
.addGap(56, 56, 56)
.addComponent(btn_rf))
);
layout.setVerticalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGap(12, 12, 12)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jButton1))
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGroup(layout.createSequentialGroup()
.addGap(59, 59, 59)
.addComponent(btn_BUY, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
.addGap(18, 18, 18)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel2)
.addComponent(txtBill, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(btn_rf))
.addContainerGap(30, Short.MAX_VALUE))
);

pack();
}// </editor-fold>//GEN-END:initComponents

private void btn_BUYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_BUYActionPerformed
dispose();        
FRSanPham Buy = new FRSanPham();
        Buy.show();


}//GEN-LAST:event_btn_BUYActionPerformed

private void btn_rfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_rfActionPerformed
       try{
            Class.forName("oracle.jdbc.driver.OracleDriver");       
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "customer", "c1");
            System.out.println("Connected to the database");           
            Statement st = con.createStatement();
            String orc = "Select sum(SP.gia_ban*DH.so_luong) \n" +
                         "FROM YUN.DonHang DH join YUN.SanPham SP\n" +
                         "on DH.ma_SP = SP.ma_SP\n" +
                         "where ma_KH = 'KH03'" ;
            //con.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            ResultSet rs = st.executeQuery(orc);
            //Thread.sleep(7000);
            //con.commit();

            if (rs.next()){
            String sum = rs.getString("sum(SP.gia_ban*DH.so_luong)");
            txtBill.setText(sum);
    }                 
            }
       catch(Exception E){
            System.out.println("Connection failed");
            E.printStackTrace();
        }
}//GEN-LAST:event_btn_rfActionPerformed

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        Customer_Manage managepage = new Customer_Manage();
        managepage.show();

}//GEN-LAST:event_jButton1ActionPerformed





public static void main(String args[]) {
/* Set the Nimbus look and feel */
//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
 */
try {
for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
if ("Nimbus".equals(info.getName())) {
javax.swing.UIManager.setLookAndFeel(info.getClassName());
break;
}
}
} catch (ClassNotFoundException ex) {
java.util.logging.Logger.getLogger(FRDonHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
java.util.logging.Logger.getLogger(FRDonHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
java.util.logging.Logger.getLogger(FRDonHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (javax.swing.UnsupportedLookAndFeelException ex) {
java.util.logging.Logger.getLogger(FRDonHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}
//</editor-fold>
//</editor-fold>

/* Create and display the form */
java.awt.EventQueue.invokeLater(new Runnable() {
public void run() {
new FRDonHang().setVisible(true);
}
});
}

// Variables declaration - do not modify//GEN-BEGIN:variables
private javax.swing.JButton btn_BUY;
private javax.swing.JButton btn_rf;
private javax.swing.JButton jButton1;
private javax.swing.JLabel jLabel1;
private javax.swing.JLabel jLabel2;
private javax.swing.JScrollPane jScrollPane1;
private javax.swing.JTable tblDH;
private javax.swing.JTextField txtBill;
// End of variables declaration//GEN-END:variables
}
