/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package shipper2;

import shipper.*;
import customer.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author PC
 */
public class ThongTin extends javax.swing.JFrame {

/**
 * Creates new form ThongTin
 */
public ThongTin() {
initComponents();
setLocationRelativeTo(null);

txt_MTX.setEditable(false);
txt_HT.setEditable(false);
txt_DC.setEditable(false);
txt_CMND.setEditable(false);
txt_SDT.setEditable(false);
txt_BXS.setEditable(false);
showTT();
}
public void showTT()
{
try{      
   String query ="select* from YUN.Taixe where ma_TX='TX01'";
     Class.forName("oracle.jdbc.driver.OracleDriver");       
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "shipper1", "1");
     //String orc ="update YUN.sanPham set ten_san_pham=?, ma_nha_cung_cap=?, ma_loai_hang=?, gia_nhap=?, gia_ban=? where ma_SP = ?";
      //con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // chỉnh giá sản phẩm cho Non-read
       Statement st = con.createStatement();
       ResultSet rs = st.executeQuery(query);

        if (rs.next())
{
     txt_HT.setText(rs.getString("Ho_ten"));
     txt_CMND.setText(rs.getString("CMND"));
     txt_SDT.setText(rs.getString("SDT_TX"));
     txt_DC.setText(rs.getString("Dia_chi_TX"));
     txt_BXS.setText(rs.getString("bien_so_xe"));
     txt_MKV.setText(rs.getString("ma_kv_hd"));
}
       else { txt_CMND.setText("");}
   } catch(Exception e)
{
       JOptionPane.showMessageDialog(this,e.getMessage());
}

}
@SuppressWarnings("unchecked")
// <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
private void initComponents() {

jLabel1 = new javax.swing.JLabel();
jLabel2 = new javax.swing.JLabel();
jLabel3 = new javax.swing.JLabel();
jLabel4 = new javax.swing.JLabel();
jLabel5 = new javax.swing.JLabel();
jLabel6 = new javax.swing.JLabel();
txt_HT = new javax.swing.JTextField();
txt_CMND = new javax.swing.JTextField();
txt_MTX = new javax.swing.JTextField();
txt_SDT = new javax.swing.JTextField();
txt_DC = new javax.swing.JTextField();
btn_Save = new javax.swing.JButton();
btn_GH = new javax.swing.JButton();
txt_MKV = new javax.swing.JTextField();
jLabel7 = new javax.swing.JLabel();
jLabel8 = new javax.swing.JLabel();
txt_BXS = new javax.swing.JTextField();

setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
jLabel1.setText("Thông tin cá nhân");

jLabel2.setText("Mã tài xế");

jLabel3.setText("Họ tên");

jLabel4.setText("CMND");

jLabel5.setText("Số điện thoại");

jLabel6.setText("Địa chỉ");

txt_HT.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_HTActionPerformed(evt);
}
});

txt_CMND.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_CMNDActionPerformed(evt);
}
});

txt_MTX.setText("TX03");
txt_MTX.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_MTXActionPerformed(evt);
}
});

txt_SDT.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_SDTActionPerformed(evt);
}
});

txt_DC.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_DCActionPerformed(evt);
}
});

btn_Save.setText("LƯU");
btn_Save.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_SaveActionPerformed(evt);
}
});

btn_GH.setText("Đơn hàng");
btn_GH.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
btn_GHActionPerformed(evt);
}
});

txt_MKV.addActionListener(new java.awt.event.ActionListener() {
public void actionPerformed(java.awt.event.ActionEvent evt) {
txt_MKVActionPerformed(evt);
}
});

jLabel7.setText("Mã khu vực");

jLabel8.setText("Biển số xe");

javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
getContentPane().setLayout(layout);
layout.setHorizontalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGap(259, 259, 259)
.addComponent(jLabel1)
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
.addComponent(btn_GH)
.addContainerGap(101, Short.MAX_VALUE))
.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
.addGap(0, 0, Short.MAX_VALUE)
.addComponent(btn_Save)
.addGap(171, 171, 171))
.addGroup(layout.createSequentialGroup()
.addGap(53, 53, 53)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel2)
.addComponent(jLabel4)
.addComponent(jLabel6)
.addComponent(jLabel8))
.addGap(56, 56, 56)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
.addComponent(txt_MTX, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
.addComponent(txt_CMND, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
.addComponent(txt_DC))
.addGap(73, 73, 73)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(jLabel3)
.addComponent(jLabel5))
.addGap(30, 30, 30)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(txt_HT, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
.addGroup(layout.createSequentialGroup()
.addComponent(jLabel7)
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
.addComponent(txt_MKV, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
.addGap(92, 92, 92))
.addGroup(layout.createSequentialGroup()
.addComponent(txt_BXS, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
);
layout.setVerticalGroup(
layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
.addGroup(layout.createSequentialGroup()
.addContainerGap()
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel1)
.addComponent(btn_GH))
.addGap(26, 26, 26)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel2)
.addComponent(txt_MTX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jLabel3)
.addComponent(txt_HT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(54, 54, 54)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel4)
.addComponent(txt_CMND, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jLabel5)
.addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(50, 50, 50)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel6)
.addComponent(txt_DC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
.addComponent(jLabel7)
.addComponent(txt_MKV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
.addComponent(jLabel8)
.addComponent(txt_BXS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
.addGap(2, 2, 2)
.addComponent(btn_Save)
.addGap(27, 27, 27))
);

pack();
}// </editor-fold>//GEN-END:initComponents

private void txt_MTXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_MTXActionPerformed
txt_MTX.setEditable(false);
txt_HT.setEditable(false);
txt_CMND.setEditable(false);
txt_SDT.setEditable(false);
txt_DC.setEditable(false);
txt_MKV.setEditable(false);
txt_BXS.setEditable(false);




}//GEN-LAST:event_txt_MTXActionPerformed

private void txt_HTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_HTActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_HTActionPerformed

private void txt_SDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_SDTActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_SDTActionPerformed

private void btn_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SaveActionPerformed

     
try{      
     String query ="Update YUN.Taixe set ma_kv_hd=? where ma_TX='TX01'";
     Class.forName("oracle.jdbc.driver.OracleDriver");       
     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "shipper1", "1");
     //String orc ="update YUN.sanPham set ten_san_pham=?, ma_nha_cung_cap=?, ma_loai_hang=?, gia_nhap=?, gia_ban=? where ma_SP = ?";
      //con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // chỉnh giá sản phẩm cho Non-read
      PreparedStatement pst = con.prepareStatement(query);
      pst.setString(1, txt_MKV.getText());
      pst.executeUpdate();
      JOptionPane.showMessageDialog(this,"Update Successfully");

   } catch(Exception e)
{
       JOptionPane.showMessageDialog(this,e.getMessage());
}



}//GEN-LAST:event_btn_SaveActionPerformed

private void txt_CMNDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CMNDActionPerformed
     
}//GEN-LAST:event_txt_CMNDActionPerformed

private void btn_GHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_GHActionPerformed
        dispose();
        TinhTrangDH hpage = new TinhTrangDH();
        hpage.show();


}//GEN-LAST:event_btn_GHActionPerformed

private void txt_DCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DCActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_DCActionPerformed

private void txt_MKVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_MKVActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_txt_MKVActionPerformed

/**
 * @param args the command line arguments
 */
public static void main(String args[]) {
/* Set the Nimbus look and feel */
//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
 */
try {
for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
if ("Nimbus".equals(info.getName())) {
javax.swing.UIManager.setLookAndFeel(info.getClassName());
break;
}
}
} catch (ClassNotFoundException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (javax.swing.UnsupportedLookAndFeelException ex) {
java.util.logging.Logger.getLogger(ThongTin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}
//</editor-fold>
//</editor-fold>
//</editor-fold>
//</editor-fold>

/* Create and display the form */
java.awt.EventQueue.invokeLater(new Runnable() {
public void run() {
new ThongTin().setVisible(true);
}
});
}

// Variables declaration - do not modify//GEN-BEGIN:variables
private javax.swing.JButton btn_GH;
private javax.swing.JButton btn_Save;
private javax.swing.JLabel jLabel1;
private javax.swing.JLabel jLabel2;
private javax.swing.JLabel jLabel3;
private javax.swing.JLabel jLabel4;
private javax.swing.JLabel jLabel5;
private javax.swing.JLabel jLabel6;
private javax.swing.JLabel jLabel7;
private javax.swing.JLabel jLabel8;
private javax.swing.JTextField txt_BXS;
private javax.swing.JTextField txt_CMND;
private javax.swing.JTextField txt_DC;
private javax.swing.JTextField txt_HT;
private javax.swing.JTextField txt_MKV;
private javax.swing.JTextField txt_MTX;
private javax.swing.JTextField txt_SDT;
// End of variables declaration//GEN-END:variables
}
