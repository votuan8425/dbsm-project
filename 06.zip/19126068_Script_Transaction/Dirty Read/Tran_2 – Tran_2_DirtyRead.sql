SET TRANSACTION 
ISOLATION LEVEL 
READ COMMITTED;

select * from YUN.sanpham_chinhanh;
