select * from YUN.SanPham;

update YUN.sanPham set gia_ban=500 where ma_sp='SP01';

update YUN.sanPham set gia_ban=670 where ma_sp='SP02';

