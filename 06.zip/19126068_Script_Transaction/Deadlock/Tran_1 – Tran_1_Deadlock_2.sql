update YUN.sanPham set gia_ban=400 where ma_sp='SP02';

update YUN.sanPham set gia_ban=700 where ma_sp='SP01';

select * from YUN.SanPham ;
