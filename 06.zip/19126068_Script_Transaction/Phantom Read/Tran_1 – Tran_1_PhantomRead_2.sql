SET TRANSACTION 
ISOLATION LEVEL 
READ COMMITTED;

select * from YUN.KhuyenMai;
commit;
