SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

select * from YUN.sanPham;



rollback;